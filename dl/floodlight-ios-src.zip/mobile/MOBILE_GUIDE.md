# Floodlight Baseball on iPhone and Android

The phone apps are the full game (the same as the Steam version), wrapped as a real app with Capacitor.
Everything plays offline: the announcer, crowd, fonts and saves all live on the phone. Only the Daily
Challenge leaderboard uses the internet.

What the apps add over the website:

- **Android back button**: closes whatever is open, opens the menu during a game, and puts the app away from the menu.
- **Vibration**: a light tap on every roll, a buzz on home runs, grand slams and walk-offs (Settings > Vibration).
- **Saves are protected**: the game saves when you switch apps, and keeps a backup copy in the app's own files.
  If the phone ever clears the game's storage, the saves come back on the next launch.
- **Save files** go through the phone's share sheet (save to Files or Drive, or send to yourself).
- **Notch and home bar**: the game stays clear of them. Phones play in portrait; tablets turn any way.

App ID (both stores): `com.floodlightbaseball.app`. Version 1.6.0.

---

## Android (ready now)

The kit has three Android files:

| File | What it's for |
|---|---|
| `floodlight-baseball-1.6.0.apk` | Install straight onto any Android phone to play and test. |
| `floodlight-baseball-1.6.0.aab` | The file Google Play wants. Upload this one to Play Console. |
| `FloodlightBaseball-Android-Upload-Key.zip` (separate download) | Your upload key and its password. Keep it private and backed up. |

### Play it on your phone today
1. Send the `.apk` to your phone (email it to yourself, or put it in Google Drive) and tap it.
2. Android asks to allow installs from that app (Drive, Gmail, Files): allow it, then tap Install.

### Put it on Google Play
1. Make a Google Play developer account at play.google.com/console (one-time $25, plus ID verification).
2. Create app > name **Floodlight Baseball**, Game, Paid (or Free).
3. New personal developer accounts must run a **closed test with at least 12 testers for 14 days** before
   the app can go to production. Upload the `.aab` to the Closed testing track and invite 12 people (Discord is great for this).
4. Fill in the store listing (text below), content rating questionnaire (no violence, no ads, no data collected),
   data safety (no data collected or shared), and price.
5. Keep **Play App Signing** on (the default). Google holds the real signing key; yours is only the upload key,
   so if it's ever lost, Google can reset it.

Every new upload needs a higher `versionCode` (in `android/app/build.gradle`): 10600 is 1.6.0, use 10601, 10700 and so on.

### Rebuild Android yourself (optional)
On any computer with Android Studio: open the `android` folder, put `keystore.properties` and
`floodlight-upload.jks` from the upload-key zip into `android/`, then Build > Generate Signed Bundle.
Or from a terminal in `mobile/`: `npm install`, `npx cap sync`, then `npm run android:release`.

---

## iPhone

Apple only lets apps onto iPhones through its own system, so the iPhone app needs:

- An **Apple Developer Program** membership: $99 a year, at developer.apple.com/programs (use the Apple ID
  you want on the store page; individual is fine).
- A Mac with Xcode **or** the cloud build already set up in your GitHub repo (no Mac needed).

The iPhone project is ready (`mobile/ios`). Icons, launch screen, name, portrait lock and permissions are all set.

### No Mac: build it in the cloud (GitHub Actions)
The repo has a workflow called **iPhone app** (Actions tab > iPhone app > Run workflow).

- Run it now and it builds the app for the iPhone simulator, which proves it compiles.
- To send real builds to your iPhone (TestFlight) and the App Store, add four secrets once
  (repo Settings > Secrets and variables > Actions > New repository secret):
  1. `APPLE_TEAM_ID`: developer.apple.com > Account > Membership details > Team ID.
  2. In App Store Connect > Users and Access > Integrations > App Store Connect API, create a key with **Admin** access.
     `ASC_KEY_ID` is its Key ID, `ASC_ISSUER_ID` is the Issuer ID above the list.
  3. `ASC_KEY_P8`: download the key (`AuthKey_….p8`, you can only download it once), open it in a text editor and paste all of it.
  4. In App Store Connect > Apps > + New App: iOS, name **Floodlight Baseball**, bundle ID `com.floodlightbaseball.app`
     (if it isn't in the list yet, run the workflow once with the secrets set; it registers it), SKU `floodlight-baseball`.
- Run **iPhone app** again. About 15 minutes later the build appears in App Store Connect > TestFlight.
  Install the TestFlight app on your iPhone to play it, then submit it for review from the App Store tab.

### With a Mac
1. Install Xcode (Mac App Store) and Node.js 22.
2. In `mobile/`: `npm install`, then `npx cap sync ios`, then `npx cap open ios`.
3. In Xcode: click **App** > Signing & Capabilities > Team: your developer team.
4. Plug in your iPhone and press Run to play it, or Product > Archive > Distribute App to upload it to the App Store.

Each upload needs a new build number (Xcode: App > General > Build). The cloud workflow does this for you.

---

## Store listing (both stores)

**Name:** Floodlight Baseball
**Subtitle (iPhone, 30 characters):** Strategy baseball with dice
**Short description (Android, 80 characters):** Roll the dice, play your cards and run a franchise under the lights.

**Description:**
Floodlight Baseball is strategy baseball you play with dice and cards on a lit-up mini stadium.

Every at-bat is a roll. Pick the Simulation die for real-baseball odds or the Arcade die for wild swings, then
bend the game with action cards, player abilities and your designated hitter. An announcer calls every play,
the crowd reacts, and the seventh-inning stretch gets everyone on their feet.

- Quick games against the computer (three skill levels) or pass-and-play with a friend
- Franchise mode: run a club through a 32-game season split into a West and an East conference,
  an All-Star Game at the halfway mark, six-team playoffs with wild card games, and the best-of-7 Floodlight Series
- Watch the computer's playoff games live, follow the bracket, and chase Player of the Week,
  Rookie of the Year, Slugger of the Year and MVP
- Trades, a rookie draft (worst record picks first), aging, retirements and a Hall of Fame
- Twelve ballparks, each with its own colors and name, plus the grand Floodlight Series stadium
- Clutch Challenges and a Daily Challenge with an online leaderboard
- Achievements, a trophy case and three franchise save slots
- Plays offline. No ads, no in-app purchases, no account.

**Category:** Games > Sports (Apple: Games, secondary Sports or Board)
**Age rating:** 4+ / Everyone
**Privacy:** the app collects no personal data. The Daily Challenge leaderboard stores only the name
the player types and their score. Apple and Google both ask for a privacy policy link: the simplest is a short
page on the website saying exactly that.

**Price idea:** $4.99 on phones (mobile players expect less than PC; Steam stays $7.99). Both stores take 15%
for small developers once you join their small-business programs (Apple Small Business Program, Google's 15% tier).

---

## Screenshots the stores ask for
- iPhone: 6.9" display (1320 × 2868 or 1290 × 2796), at least 3. iPad 13" too if the app runs on iPad (it does).
- Android: at least 2 phone screenshots, plus a 1024 × 500 feature graphic.
The kit's `store-screens/` folder has phone screenshots at these sizes.

## For a developer (how it's built)
- `python3 build.py` (repo root) builds the web, desktop and phone pages. The phone page is
  `mobile/www/index.html`: the desktop page (local fonts and sound) plus `capacitor.js` and `viewport-fit=cover`.
- `src/js/58-app.js` holds the phone-only code (back button, haptics, backup, share sheet); it only runs when
  `window.Capacitor` says it's inside the app. App CSS lives under `html.app` in `src/addons.css`.
- `npx cap sync` copies `www/` into both native projects. Icons and launch screens come from `mobile/assets/`
  (redraw with `python3 mobile/tools/make_assets.py`, then `npx capacitor-assets generate`).
- Capacitor 8.5, Android target SDK 36 (min 24), iOS 15+, Swift Package Manager (no CocoaPods).
